
//This is the global array that will store the CSV file that the data will be stored in once the survey is complete
global.shared = {
    surveyArray: [],
    layout: [],
    survey: [],
    createLayout: [],
    areadata: []
}

module.exports = global;